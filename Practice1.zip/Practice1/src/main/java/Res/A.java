package Res;
import java.io.File;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class A{
	
	
public static WebDriver driver;
public static Properties prop;
public int i=5;

public static WebDriver Intializebrowser() throws IOException
	{
	
	prop= new Properties();
	FileInputStream fis=new FileInputStream("C:\\Users\\mpalvadi\\.eclipse\\Practice1\\src\\main\\resources\\irctc.properties");
	prop.load(fis);	
	
	
		String browser=prop.getProperty("browser");
		if(browser.equals("chrome"))
			{
			        System.setProperty("WebDriver.chrome.driver","C:\\Geckodriver\\Chrome\\chromedriver_win32\\chromedriver.exe" );
					driver=new ChromeDriver();
					
			}
		else if(browser.equals("firefox"))
		{
			System.setProperty("WebDriver.gecko.driver","C:\\Geckodriver\\geckodriver.exe" );
			driver=new FirefoxDriver();
			
			
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}
	
public static int check()
{
	int k=11;
	return k;
}
}

