package PageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Res.A;


public class LoginPage extends A{

	

	public static WebElement UserName()
	
	{	
		WebElement UserName=driver.findElement(By.xpath("//div[@class='grid_16 alpha']/table[1]/tbody[1]/tr[1]/td[2]/input[@id='usernameId']"));
		return UserName;				
	}
	
	
	public static WebElement Password()
	
	{
		
		WebElement Password=driver.findElement(By.xpath("//div[@class='grid_16 alpha']/table[1]/tbody[1]/tr[2]/td[2]/input[@class='loginPassword']"));
		return null;
		
	}
	
	
	public static WebElement LoginButton()
	{
		WebElement LoginButton=driver.findElement(By.xpath("//div[@class='grid_6']/input[@id='loginbutton']"));
		return LoginButton;
	}
}
