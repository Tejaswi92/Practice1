import java.io.IOException;


import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import PageObjects.LoginPage;
import Res.A;


public class Login extends A {

	
@Test(dataProvider="getLoginData")
		public void loginbrowser(String Username,String Password) throws IOException
	{
		 
		 driver=Intializebrowser();
	     driver.get(prop.getProperty("url"));
	     LoginPage.UserName().sendKeys(Username);
	     LoginPage.Password().sendKeys(Password);
		
		
		
		
		
		
	}
	@AfterTest
	public void teardown()
	{
		
		driver.close();
		driver=null;
		
	}

	
	@DataProvider (name="getLoginData")
	public Object[][] getLoginData()
	{
		Object[][] data=new Object[2][2];
		
		data[0][0]="toshita92";
		data[0][1]="willpower";
		
		//1st row
		data[1][0]="mohankk200";
		data[1][1]="mdj315";
		return data;
		
		
	}
}
